// Pulse Macro Studio — single-file Win32 C++17 starter
// Build in Visual Studio: Windows Desktop Application / Empty Project, add this file.
// Link: user32.lib, gdi32.lib, comctl32.lib
// Note: This is a general desktop macro utility. Use responsibly; some apps/games prohibit automation.

#define UNICODE
#define _UNICODE
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <cstdio>

#pragma comment(lib, "Comctl32.lib")
#pragma comment(lib, "Comdlg32.lib")

struct MacroAction { WORD vk; int delayMs; };
static std::vector<MacroAction> g_actions = {{'A',100},{'B',100}};
static HWND g_main=nullptr, g_list=nullptr, g_delay=nullptr, g_key=nullptr, g_status=nullptr, g_repeat=nullptr;
static HWND g_add=nullptr, g_remove=nullptr, g_start=nullptr, g_stop=nullptr, g_save=nullptr, g_triggerLabel=nullptr;
static HHOOK g_hook=nullptr;
static bool g_running=false, g_holdMode=true, g_keyDown=false, g_stopRequested=false, g_capturing=false;
static WORD g_trigger=VK_F6;
static HANDLE g_worker=nullptr;
static HFONT g_font=nullptr, g_bold=nullptr;
static const COLORREF BG=RGB(10,11,17), PANEL=RGB(18,20,30), PANEL2=RGB(13,15,23);
static const COLORREF PURPLE=RGB(167,139,250), TEXT=RGB(241,240,250), MUTED=RGB(150,152,176), BORDER=RGB(43,45,62);

static std::wstring VkName(WORD vk) {
    if(vk>=0x30 && vk<=0x5A) return std::wstring(1,(wchar_t)vk);
    switch(vk) {
    case VK_SPACE:return L"Space"; case VK_RETURN:return L"Enter"; case VK_TAB:return L"Tab";
    case VK_ESCAPE:return L"Esc"; case VK_BACK:return L"Backspace"; case VK_SHIFT:return L"Shift";
    case VK_CONTROL:return L"Ctrl"; case VK_MENU:return L"Alt"; case VK_F1:return L"F1";
    case VK_F2:return L"F2"; case VK_F3:return L"F3"; case VK_F4:return L"F4"; case VK_F5:return L"F5";
    case VK_F6:return L"F6"; case VK_F7:return L"F7"; case VK_F8:return L"F8"; case VK_F9:return L"F9";
    case VK_F10:return L"F10"; case VK_F11:return L"F11"; case VK_F12:return L"F12";
    default:return L"Key "+std::to_wstring(vk);
    }
}
static WORD ParseKey(std::wstring s) {
    if(s.empty()) return 'A';
    for(auto& c:s)c=(wchar_t)towupper(c);
    if(s==L"SPACE")return VK_SPACE; if(s==L"ENTER")return VK_RETURN; if(s==L"TAB")return VK_TAB;
    if(s==L"ESC")return VK_ESCAPE; if(s==L"BACKSPACE")return VK_BACK;
    if(s.size()==1) return (WORD)s[0];
    if(s[0]==L'F' && s.size()<=3) { int n=_wtoi(s.c_str()+1); if(n>=1&&n<=12)return (WORD)(VK_F1+n-1); }
    return 'A';
}
static void SetStatus(const std::wstring& s) { if(g_status) SetWindowTextW(g_status,s.c_str()); }
static void RefreshList() {
    if(!g_list)return;
    SendMessageW(g_list,LB_RESETCONTENT,0,0);
    for(size_t i=0;i<g_actions.size();++i) {
        std::wstring s=std::to_wstring(i+1)+L".  Key Press  ·  "+VkName(g_actions[i].vk)+L"      Delay: "+std::to_wstring(g_actions[i].delayMs)+L" ms";
        SendMessageW(g_list,LB_ADDSTRING,0,(LPARAM)s.c_str());
    }
}
static void SendKey(WORD vk, bool down) {
    INPUT in{}; in.type=INPUT_KEYBOARD; in.ki.wVk=vk; if(!down)in.ki.dwFlags=KEYEVENTF_KEYUP;
    SendInput(1,&in,sizeof(in));
}
static DWORD WINAPI MacroThread(LPVOID) {
    int repeat=1;
    if(g_repeat) { wchar_t b[32]{}; GetWindowTextW(g_repeat,b,32); repeat=_wtoi(b); }
    if(repeat<1) repeat=20;
    repeat=std::min(repeat,20);
    for(int r=0;r<repeat && !g_stopRequested;++r) {
        for(const auto& a:g_actions) {
            if(g_stopRequested || (g_holdMode && !g_keyDown)) break;
            SendKey(a.vk,true); Sleep(25); SendKey(a.vk,false);
            int waited=0; while(waited<a.delayMs && !g_stopRequested && (!g_holdMode||g_keyDown)) { Sleep(10); waited+=10; }
        }
        if(g_holdMode && !g_keyDown) break;
    }
    g_running=false;
    PostMessageW(g_main,WM_APP+1,0,0);
    return 0;
}
static void StartMacro() {
    if(g_running || g_actions.empty())return;
    g_stopRequested=false; g_running=true;
    g_worker=CreateThread(nullptr,0,MacroThread,nullptr,0,nullptr);
    SetStatus(L"Macro running · trigger "+VkName(g_trigger));
}
static void StopMacro() {
    g_stopRequested=true;
    if(g_running)SetStatus(L"Stopping macro...");
    else SetStatus(L"Macro stopped");
}
static LRESULT CALLBACK KeyboardHook(int nCode, WPARAM wp, LPARAM lp) {
    if(nCode==HC_ACTION) {
        KBDLLHOOKSTRUCT* k=(KBDLLHOOKSTRUCT*)lp;
        bool down=(wp==WM_KEYDOWN||wp==WM_SYSKEYDOWN), up=(wp==WM_KEYUP||wp==WM_SYSKEYUP);
        if(g_capturing && (wp==WM_KEYDOWN || wp==WM_SYSKEYDOWN) && !(k->flags&LLKHF_INJECTED)) {
            g_trigger=(WORD)k->vkCode;
            g_capturing=false;
            PostMessageW(g_main,WM_APP+4,0,0);
            return 1;
        }
        if(k->vkCode==g_trigger && !(k->flags&LLKHF_INJECTED)) {
            if(g_holdMode) {
                if(down && !g_keyDown) { g_keyDown=true; PostMessageW(g_main,WM_APP+2,1,0); }
                if(up && g_keyDown) { g_keyDown=false; PostMessageW(g_main,WM_APP+2,0,0); }
            } else if(down && !(k->flags&LLKHF_UP)) {
                static ULONGLONG last=0; ULONGLONG now=GetTickCount64();
                if(now-last>250) { last=now; PostMessageW(g_main,WM_APP+3,0,0); }
            }
        }
    }
    return CallNextHookEx(g_hook,nCode,wp,lp);
}
static HWND MakeControl(const wchar_t* cls,const wchar_t* text,DWORD style,int x,int y,int w,int h,HWND parent,int id) {
    HWND hWnd=CreateWindowExW(0,cls,text,WS_CHILD|WS_VISIBLE|style,x,y,w,h,parent,(HMENU)(INT_PTR)id,GetModuleHandleW(nullptr),nullptr);
    if(g_font)SendMessageW(hWnd,WM_SETFONT,(WPARAM)g_font,TRUE);
    return hWnd;
}
static void Label(HWND p,const wchar_t* text,int x,int y,int w,int h,bool bold=false) {
    HWND h=MakeControl(L"STATIC",text,0,x,y,w,h,p,0);
    SendMessageW(h,WM_SETFONT,(WPARAM)(bold?g_bold:g_font),TRUE);
}
static void Button(HWND p,const wchar_t* text,int x,int y,int w,int h,int id) {
    MakeControl(L"BUTTON",text,BS_PUSHBUTTON,x,y,w,h,p,id);
}
static void DrawTextColor(HDC dc,const wchar_t* s,RECT r,COLORREF c,HFONT f) {
    SetTextColor(dc,c); SetBkMode(dc,TRANSPARENT); HFONT old=(HFONT)SelectObject(dc,f); DrawTextW(dc,s,-1,&r,DT_LEFT|DT_VCENTER|DT_SINGLELINE); SelectObject(dc,old);
}
static LRESULT CALLBACK WndProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp) {
    switch(msg) {
    case WM_CREATE: {
        g_main=hwnd;
        g_font=CreateFontW(18,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        g_bold=CreateFontW(20,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        // Header
        Label(hwnd,L"ϟ",24,15,42,42,true); Label(hwnd,L"Pulse",70,12,70,30,true); Label(hwnd,L"Macro Studio",135,12,190,30,true);
        Label(hwnd,L"BUILD  ·  BIND  ·  REPEAT",72,39,250,18,false);
        Label(hwnd,L"LOCAL DESKTOP MACRO",650,22,220,24,false);
        // Sidebar panel
        Label(hwnd,L"WORKSPACE",22,87,150,20,true);
        Button(hwnd,L"Macro Builder",18,115,165,36,101);
        Button(hwnd,L"Presets",18,158,165,36,102);
        Button(hwnd,L"Key Bindings",18,201,165,36,103);
        Button(hwnd,L"About",18,244,165,36,104);
        Label(hwnd,L"SESSION",22,310,150,20,true);
        Label(hwnd,L"●  Macro stopped",22,338,160,22,false);
        Label(hwnd,L"Use a test app or text",22,390,170,20,false);
        Label(hwnd,L"editor for simple key",22,411,170,20,false);
        Label(hwnd,L"sequences. Avoid using",22,432,170,20,false);
        Label(hwnd,L"macros where prohibited.",22,453,170,20,false);
        // Main panel
        Label(hwnd,L"Macro Builder",210,86,280,34,true);
        Label(hwnd,L"Create a sequence of key presses with adjustable delays.",210,117,520,22,false);
        Label(hwnd,L"ACTION SEQUENCE",210,159,250,24,true);
        g_list=MakeControl(L"LISTBOX",L"",WS_BORDER|WS_VSCROLL|LBS_NOTIFY|LBS_NOINTEGRALHEIGHT,210,190,455,200,hwnd,201);
        Button(hwnd,L"+ Add Action",210,400,125,34,202); Button(hwnd,L"Remove Selected",344,400,145,34,203);
        Label(hwnd,L"New action key (A, B, Space, Enter, F1…F12)",210,447,420,22,false);
        g_key=MakeControl(L"EDIT",L"C",WS_BORDER|ES_AUTOHSCROLL,210,472,160,30,hwnd,204);
        Label(hwnd,L"Delay (ms)",390,447,120,22,false);
        g_delay=MakeControl(L"EDIT",L"100",WS_BORDER|ES_NUMBER,390,472,100,30,hwnd,205);
        // Right settings
        Label(hwnd,L"MACRO SETTINGS",690,86,220,24,true);
        Label(hwnd,L"Macro name",690,123,180,20,false);
        MakeControl(L"EDIT",L"My Macro",WS_BORDER|ES_AUTOHSCROLL,690,147,220,30,hwnd,206);
        Label(hwnd,L"Trigger key",690,190,180,20,false);
        g_triggerLabel=MakeControl(L"STATIC",L"F6",SS_CENTER|WS_BORDER,690,214,80,30,hwnd,207);
        Button(hwnd,L"Bind key",780,214,130,30,208);
        Label(hwnd,L"Activation mode",690,258,180,20,false);
        g_repeat=MakeControl(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL,690,282,220,180,hwnd,209);
        SendMessageW(g_repeat,CB_ADDSTRING,0,(LPARAM)L"1");SendMessageW(g_repeat,CB_ADDSTRING,0,(LPARAM)L"3");SendMessageW(g_repeat,CB_ADDSTRING,0,(LPARAM)L"5");SendMessageW(g_repeat,CB_ADDSTRING,0,(LPARAM)L"10");SendMessageW(g_repeat,CB_ADDSTRING,0,(LPARAM)L"20");
        SendMessageW(g_repeat,CB_SETCURSEL,0,0);
        Label(hwnd,L"Repeat count (choose 1, 3, 5, 10, 20)",690,315,230,35,false);
        Button(hwnd,L"▶  Test Macro",690,365,220,40,210); Button(hwnd,L"■  Stop",690,412,220,36,211);
        Button(hwnd,L"Export Macro JSON",690,462,220,36,212);
        g_status=MakeControl(L"STATIC",L"Ready · no playback active",SS_LEFT,210,535,700,26,hwnd,213);
        RefreshList();
        g_hook=SetWindowsHookExW(WH_KEYBOARD_LL,KeyboardHook,GetModuleHandleW(nullptr),0);
        return 0;
    }
    case WM_ERASEBKGND:
        // WM_PAINT owns the full background; suppress the default white erase.
        return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps{}; HDC dc=BeginPaint(hwnd,&ps); RECT r{}; GetClientRect(hwnd,&r);
        HBRUSH b=CreateSolidBrush(BG); FillRect(dc,&r,b); DeleteObject(b);
        RECT header={0,0,r.right,70}; b=CreateSolidBrush(RGB(12,12,19)); FillRect(dc,&header,b); DeleteObject(b);
        HPEN pen=CreatePen(PS_SOLID,1,RGB(68,48,101)); HPEN old=(HPEN)SelectObject(dc,pen);
        MoveToEx(dc,0,69,nullptr); LineTo(dc,r.right,69); SelectObject(dc,old); DeleteObject(pen);
        RECT side={12,78,195,r.bottom-12}; b=CreateSolidBrush(PANEL); FillRect(dc,&side,b); DeleteObject(b);
        RECT center={202,78,678,r.bottom-12}; b=CreateSolidBrush(PANEL); FillRect(dc,&center,b); DeleteObject(b);
        RECT right={683,78,r.right-12,r.bottom-12}; b=CreateSolidBrush(PANEL); FillRect(dc,&right,b); DeleteObject(b);
        EndPaint(hwnd,&ps); return 0;
    }
    case WM_CTLCOLORSTATIC: {
        HDC dc=(HDC)wp;SetBkMode(dc,TRANSPARENT);SetTextColor(dc,TEXT);return (LRESULT)GetStockObject(NULL_BRUSH);
    }
    case WM_CTLCOLOREDIT:case WM_CTLCOLORLISTBOX:case WM_CTLCOLORBTN:case WM_CTLCOLORMSGBOX: {
        HDC dc=(HDC)wp;SetTextColor(dc,TEXT);SetBkColor(dc,PANEL2);static HBRUSH br=CreateSolidBrush(PANEL2);return (LRESULT)br;
    }
    case WM_COMMAND:
        switch(LOWORD(wp)) {
        case 101: SetStatus(L"Macro Builder selected");break;
        case 102: MessageBoxW(hwnd,L"Starter preset: Two-Key Test. Add A and B actions with 100 ms delays.",L"Pulse Presets",MB_OK|MB_ICONINFORMATION);break;
        case 103: MessageBoxW(hwnd,L"Click Bind key, then press the desired trigger key. F6 is the default.",L"Key Bindings",MB_OK|MB_ICONINFORMATION);break;
        case 104: MessageBoxW(hwnd,L"Pulse Macro Studio is a simple desktop macro utility. Use it responsibly and follow the rules of each application.",L"About",MB_OK|MB_ICONINFORMATION);break;
        case 202: {
            if(g_actions.size()>=20){MessageBoxW(hwnd,L"Maximum 20 actions.",L"Pulse",MB_OK);break;}
            wchar_t kb[64]{},db[64]{};GetWindowTextW(g_key,kb,64);GetWindowTextW(g_delay,db,64);
            WORD vk=ParseKey(kb);int d=std::max(10,std::min(5000,_wtoi(db)));
            g_actions.push_back({vk,d});RefreshList();SetStatus(L"Action added");break;
        }
        case 203: {
            int i=(int)SendMessageW(g_list,LB_GETCURSEL,0,0);
            if(i!=LB_ERR&&i>=0&&i<(int)g_actions.size()){g_actions.erase(g_actions.begin()+i);RefreshList();SetStatus(L"Action removed");}
            break;
        }
        case 208: {
            g_capturing=true;
            SetWindowTextW(g_triggerLabel,L"Press key");
            SetStatus(L"Press any key to bind the trigger...");
            break;
        }
        case 210: g_holdMode=false;StartMacro();break;
        case 211: StopMacro();break;
        case 212: {
            OPENFILENAMEW ofn{};wchar_t file[MAX_PATH]=L"pulse-macro.json";ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=hwnd;ofn.lpstrFilter=L"JSON Files (*.json)\0*.json\0All Files (*.*)\0*.*\0";ofn.lpstrFile=file;ofn.nMaxFile=MAX_PATH;ofn.Flags=OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST;ofn.lpstrDefExt=L"json";
            if(GetSaveFileNameW(&ofn)){FILE* f=nullptr;_wfopen_s(&f,file,L"w, ccs=UTF-8");if(f){fwprintf(f,L"{\n  \"name\": \"My Macro\",\n  \"trigger\": \"%ls\",\n  \"actions\": [\n",VkName(g_trigger).c_str());for(size_t i=0;i<g_actions.size();++i)fwprintf(f,L"    {\"key\":\"%ls\",\"delayMs\":%d}%ls\n",VkName(g_actions[i].vk).c_str(),g_actions[i].delayMs,i+1<g_actions.size()?L",":L"");fwprintf(f,L"  ]\n}\n");fclose(f);SetStatus(L"Macro JSON exported");}}
            break;
        }
        }
        return 0;
    case WM_APP+1:
        SetStatus(L"Macro stopped");return 0;
    case WM_APP+2:
        if(wp) {g_holdMode=true;StartMacro();} else StopMacro();return 0;
    case WM_APP+3:
        if(g_running)StopMacro();else {g_holdMode=false;StartMacro();}return 0;
    case WM_APP+4:
        SetWindowTextW(g_triggerLabel,VkName(g_trigger).c_str());
        SetStatus((L"Trigger bound: "+VkName(g_trigger)+L" · hold to run").c_str());
        return 0;
    case WM_DESTROY:
        StopMacro();if(g_hook)UnhookWindowsHookEx(g_hook);if(g_worker){WaitForSingleObject(g_worker,500);CloseHandle(g_worker);}
        if(g_font)DeleteObject(g_font);if(g_bold)DeleteObject(g_bold);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE,LPWSTR,int show) {
    INITCOMMONCONTROLSEX ic{sizeof(ic),ICC_STANDARD_CLASSES};InitCommonControlsEx(&ic);
    WNDCLASSW wc{};wc.lpfnWndProc=WndProc;wc.hInstance=inst;wc.lpszClassName=L"PulseMacroStudioWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=nullptr;wc.style=CS_HREDRAW|CS_VREDRAW;
    RegisterClassW(&wc);
    HWND hwnd=CreateWindowExW(0,wc.lpszClassName,L"Pulse Macro Studio",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,960,650,nullptr,nullptr,inst,nullptr);
    if(!hwnd)return 1;ShowWindow(hwnd,show);UpdateWindow(hwnd);
    MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return (int)msg.wParam;
}
