PULSE MACRO STUDIO — AUTOMATIC WINDOWS EXE BUILD

This package is set up to compile Pulse_Macro_Studio.cpp on GitHub's Windows runner.
You do NOT need to open Visual Studio on your own PC.

1. Sign in to https://github.com/ and create a NEW repository. Name it Pulse-Macro-Studio.
   A private repository is fine. Do not add a README/license/gitignore during creation.
2. Extract this ZIP on your computer.
3. In the new repository page, choose Add file > Upload files.
   Upload Pulse_Macro_Studio.cpp and README_FIRST.txt, then commit the upload to main.
4. Create the workflow file in GitHub:
   - Click Add file > Create new file.
   - In the filename field enter: .github/workflows/build-windows.yml
   - Open the included .github/workflows/build-windows.yml in a text editor, copy all of it,
     paste it into GitHub's editor, and commit to main.
5. Open the repository's Actions tab. Select “Build Pulse Macro Studio (Windows EXE)”.
   Click “Run workflow”, then the green “Run workflow” button.
6. Wait for the run to finish. Open the completed run and find Artifacts at the bottom.
   Download “Pulse-Macro-Studio-Windows-EXE.zip”, then extract it to get Pulse_Macro_Studio.exe.
7. Double-click Pulse_Macro_Studio.exe to run it.

If the build fails, open the failed run, expand “Compile Windows executable”, and share the error text.
The EXE is not produced until the build succeeds. GitHub may ask you to verify your account.

Note: This utility sends ordinary keyboard inputs. Use only where automation is allowed.
